import pyarmnn as ann

print('armnn version:',ann.GetVersion())