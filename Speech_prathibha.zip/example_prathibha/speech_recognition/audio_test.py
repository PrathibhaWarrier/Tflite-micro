# import os
#
# import numpy as np
#
# from context import audio_capture
#
# from context import common_utils
# from context import audio_utils
#
# script_dir = os.path.dirname(__file__)
# sys.path.insert(1, os.path.join(script_dir, '..', 'common'))
import sys
import os
from argparse import ArgumentParser

script_dir = os.path.dirname(__file__)
sys.path.insert(1, os.path.join(script_dir, '..', 'common'))

from network_executor import ArmnnNetworkExecutor
from utils import dict_labels
from preprocess import MFCCParams, Preprocessor, MFCC
from audio_capture import AudioCapture, ModelParams
from audio_utils import decode_text, prepare_input_tensors, display_text


def main():
    # Read command line args
    audio_file = "quick_brown_fox_16000khz.wav"
    model = ModelParams("wav2letter_int8.tflite")
    # labels = dict_labels("F:/LTTS_vadodra/A2T/armnn-branches-armnn_21_11/python/pyarmnn/examples/speech_recognition/wav2letter_labels.txt")

    # Create the ArmNN inference runner
    network = ArmnnNetworkExecutor(model.path, ["CpuAcc", "CpuRef"])

    audio_capture = AudioCapture(model)
    buffer = audio_capture.from_audio_file(audio_file)

    # Create the preprocessor
    mfcc_params = MFCCParams(sampling_freq=16000, num_fbank_bins=128, mel_lo_freq=0, mel_hi_freq=8000,
                                        num_mfcc_feats=13, frame_len=512, use_htk_method=False, n_FFT=512)
    mfcc = MFCC(mfcc_params)
    preprocessor = Preprocessor(mfcc, model_input_size=296, stride=160)

    text = ""
    current_r_context = ""
    is_first_window = True

    print("Processing Audio Frames...")
    # for audio_data in buffer:
    #     # Prepare the input Tensors
    #     input_tensors = prepare_input_tensors(audio_data, network.input_binding_info, preprocessor)
    #
    #     # Run inference
    #     output_result = network.run(input_tensors)
    #
	# # Slice and Decode the text, and store the right context
    #     current_r_context, text = decode_text(is_first_window, labels, output_result)
    #
    #     is_first_window = False
    #
    #     display_text(text)
    #
    # print(current_r_context, flush=True)



if __name__ == "__main__":
    main()
